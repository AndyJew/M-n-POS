const KEY="man-pos-mvp-v1";
const defaultState={
 storeName:"Quán mẫu • Chi nhánh chính",
 printerDefault:"p1",
 staffCanChangePrinter:true,
 qrData:"",
 bankName:"",
 accountNumber:"",
 accountHolder:"",
 transferNote:"MAN POS",
 otherMethods:"Ví điện tử, Công nợ",
 tables:Array.from({length:12},(_,i)=>({id:i+1,name:"Bàn "+String(i+1).padStart(2,"0")})),
 products:[
  {id:1,name:"Cà phê đen",category:"Cà phê",price:20000},
  {id:2,name:"Cà phê sữa",category:"Cà phê",price:25000},
  {id:3,name:"Bạc xỉu",category:"Cà phê",price:30000},
  {id:4,name:"Trà đào",category:"Trà",price:35000},
  {id:5,name:"Trà tắc",category:"Trà",price:22000},
  {id:6,name:"Nước suối",category:"Nước",price:12000},
  {id:7,name:"Tiramisu",category:"Bánh",price:40000},
  {id:8,name:"Mì xào",category:"Đồ ăn",price:45000}
 ],
 orders:[], currentTable:null, cart:[], category:"Tất cả"
};
let state;
try{state={...defaultState,...JSON.parse(localStorage.getItem(KEY)||"{}")};}catch(e){state=structuredClone(defaultState)}
let page="home";
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function money(n){return new Intl.NumberFormat("vi-VN").format(n)+"đ"}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(msg){const old=document.querySelector(".toast");if(old)old.remove();let el=document.createElement("div");el.className="toast";el.textContent=msg;document.body.appendChild(el);setTimeout(()=>el.remove(),2500)}
function setPage(p){page=p;document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.page===p));render()}
document.getElementById("nav").addEventListener("click",e=>{const b=e.target.closest("[data-page]");if(b)setPage(b.dataset.page)});
function pageHead(title,sub="",action=""){return `<div class="page-head"><div><h1>${title}</h1>${sub?`<div class="muted">${sub}</div>`:""}</div>${action}</div>`}
function render(){
 document.getElementById("storeName").textContent=state.storeName;
 const main=document.getElementById("main");
 if(page==="home")main.innerHTML=homePage();
 if(page==="sales")main.innerHTML=salesPage();
 if(page==="tables")main.innerHTML=tablesPage();
 if(page==="orders")main.innerHTML=ordersPage();
 if(page==="menu")main.innerHTML=menuPage();
 if(page==="reports")main.innerHTML=reportsPage();
 if(page==="settings")main.innerHTML=settingsPage();
}
function homePage(){
 const today=state.orders.filter(o=>new Date(o.createdAt).toDateString()===new Date().toDateString()&&o.status==="Đã thanh toán");
 const revenue=today.reduce((s,o)=>s+o.total,0);
 const open=state.orders.filter(o=>o.status!=="Đã thanh toán");
 return `${pageHead("Tổng quan","Chào mừng đến với Mạn POS — bản MVP")}
 <div class="grid">
 <div class="card"><div class="stat-label">Doanh thu hôm nay</div><div class="stat">${money(revenue)}</div></div>
 <div class="card"><div class="stat-label">Đơn đã thanh toán hôm nay</div><div class="stat">${today.length}</div></div>
 <div class="card"><div class="stat-label">Đơn đang mở</div><div class="stat">${open.length}</div></div>
 <div class="card"><div class="stat-label">Số bàn</div><div class="stat">${state.tables.length}</div></div>
 </div><div class="panel" style="margin-top:16px"><h2>Bắt đầu nhanh</h2><div class="actions">
 <button class="btn primary" onclick="setPage('sales')">＋ Bán hàng</button><button class="btn" onclick="setPage('tables')">▤ Sơ đồ bàn</button><button class="btn" onclick="setPage('menu')">☕ Quản lý thực đơn</button><button class="btn" onclick="setPage('settings')">⚙ Cài đặt máy in & QR</button></div></div>
 <div class="panel" style="margin-top:16px"><h2>Đơn hàng gần đây</h2>${state.orders.length?ordersTable(state.orders.slice().reverse().slice(0,5)):'<div class="empty">Chưa có đơn hàng. Hãy vào Bán hàng để tạo đơn demo.</div>'}</div>`;
}
function tableStatus(t){const o=state.orders.find(o=>o.tableId===t.id&&o.status!=="Đã thanh toán");return o?o.status==="Chờ thanh toán"?"wait":"busy":""}
function tableTile(t){const o=state.orders.find(o=>o.tableId===t.id&&o.status!=="Đã thanh toán");let cls=tableStatus(t);return `<button class="table-tile ${cls}" onclick="openTable(${t.id})"><strong>🚪 ${esc(t.name)}</strong><span class="pill ${cls}">${o?esc(o.status):"Trống"}</span><div style="margin-top:8px;font-weight:750">${o?money(o.total):"—"}</div></button>`}
function tablesPage(){return `${pageHead("Bàn","Chọn bàn để tạo hoặc tiếp tục order.",'<button class="btn" onclick="addTable()">＋ Thêm bàn</button>')}<div class="table-grid">${state.tables.map(tableTile).join("")}</div>`}
function salesPage(){
 if(state.currentTable===null)return `${pageHead("Bán hàng","Chọn bàn trước khi thêm món.")}<div class="table-grid">${state.tables.map(tableTile).join("")}</div>`;
 const t=state.tables.find(t=>t.id===state.currentTable);
 const cats=["Tất cả",...new Set(state.products.map(p=>p.category))];
 const products=state.products.filter(p=>state.category==="Tất cả"||p.category===state.category);
 return `${pageHead("Bán hàng",`${esc(t?.name||"Bàn")} • Chọn món để thêm vào order`, `<button class="btn" onclick="chooseAnotherTable()">↔ Đổi bàn</button>`)}
 <div class="two-col"><section class="panel"><div class="categories">${cats.map(c=>`<button class="category ${state.category===c?"active":""}" onclick="setCategory('${esc(c)}')">${esc(c)}</button>`).join("")}</div><div class="products">${products.map(p=>`<button class="product" onclick="addProduct(${p.id})"><strong>${esc(p.name)}</strong><span class="price">${money(p.price)}</span><div class="muted" style="font-size:12px;margin-top:6px">${esc(p.category)}</div></button>`).join("")}</div></section>
 <section class="panel"><h2>Order • ${esc(t?.name||"")}</h2>${state.cart.length?state.cart.map((it,i)=>`<div class="order-line"><div><strong>${esc(it.name)}</strong><div class="muted">${money(it.price)} / món</div></div><div class="qty"><button onclick="changeQty(${i},-1)">−</button><b>${it.qty}</b><button onclick="changeQty(${i},1)">＋</button></div><b>${money(it.price*it.qty)}</b></div>`).join(""):'<div class="empty">Chưa có món. Chạm vào món bên trái để thêm.</div>'}
 <div class="total-row"><span>Tạm tính</span><span>${money(cartTotal())}</span></div><div class="actions"><button class="btn soft" onclick="showPrintModal()">GỬI IN</button><button class="btn primary" onclick="showPaymentModal()" ${state.cart.length?"":"disabled"}>THANH TOÁN</button><button class="btn" onclick="clearCart()">Xóa món</button></div><p class="hint">Gửi in hiện mô phỏng lựa chọn máy in, chưa kết nối máy in vật lý.</p></section></div>`;
}
function setCategory(c){state.category=c;render()}
function openTable(id){state.currentTable=id;const existing=state.orders.find(o=>o.tableId===id&&o.status!=="Đã thanh toán");state.cart=existing?existing.items.map(x=>({...x})):[];state.category="Tất cả";setPage("sales")}
function chooseAnotherTable(){state.currentTable=null;state.cart=[];setPage("sales")}
function addProduct(id){const p=state.products.find(p=>p.id===id);if(!p)return;let it=state.cart.find(x=>x.id===id);if(it)it.qty++;else state.cart.push({...p,qty:1});render()}
function changeQty(i,d){if(!state.cart[i])return;state.cart[i].qty+=d;if(state.cart[i].qty<=0)state.cart.splice(i,1);render()}
function cartTotal(){return state.cart.reduce((s,x)=>s+x.price*x.qty,0)}
function clearCart(){state.cart=[];render()}
function showPrintModal(){
 if(!state.cart.length){toast("Hãy chọn món trước khi gửi in.");return}
 const selected=state.printerDefault;
 modal(`<h2>GỬI IN</h2><p class="muted">Chọn máy in nhận order cho ${esc(state.tables.find(t=>t.id===state.currentTable)?.name||"bàn")}.</p>
 <label class="checkline"><input type="radio" name="printer" value="p1" ${selected==="p1"?"checked":""} ${!state.staffCanChangePrinter&&selected!=="p1"?"disabled":""}> Máy in 1</label>
 <label class="checkline"><input type="radio" name="printer" value="both" ${selected==="both"?"checked":""} ${!state.staffCanChangePrinter&&selected!=="both"?"disabled":""}> Máy in 1 + Máy in 2</label>
 ${!state.staffCanChangePrinter?'<p class="hint">Chủ quán đã khóa lựa chọn. Mạn dùng cấu hình mặc định.</p>':''}
 <p class="hint">Bản MVP chỉ ghi nhận lựa chọn; muốn in thật cần cấu hình và kiểm tra tương thích máy in.</p>
 <div class="modal-actions"><button class="btn" onclick="closeModal()">Hủy</button><button class="btn primary" onclick="confirmPrint()">Xác nhận gửi in</button></div>`);
}
function confirmPrint(){const choice=document.querySelector('input[name="printer"]:checked')?.value||state.printerDefault;let order=getOrCreateOrder("Đang phục vụ");order.printer=choice;order.printCount=(order.printCount||0)+1;order.items=state.cart.map(x=>({...x}));order.total=cartTotal();order.status="Đang phục vụ";order.updatedAt=new Date().toISOString();save();closeModal();toast(choice==="both"?"Đã ghi nhận gửi in: Máy 1 + Máy 2":"Đã ghi nhận gửi in: Máy 1");render()}
function getOrCreateOrder(status){let o=state.orders.find(o=>o.tableId===state.currentTable&&o.status!=="Đã thanh toán");if(!o){o={id:Date.now(),tableId:state.currentTable,createdAt:new Date().toISOString(),items:[],total:0,status};state.orders.push(o)}return o}
function showPaymentModal(){
 if(!state.cart.length){toast("Hãy chọn món trước khi thanh toán.");return}
 const total=cartTotal();
 modal(`<h2>THANH TOÁN</h2><div class="qr-box"><div class="muted">Tổng tiền</div><div class="stat">${money(total)}</div></div>
 <div class="cards"><button class="btn primary" onclick="cashPayment()">💵 TIỀN MẶT</button><button class="btn primary" onclick="transferPayment()">▦ CHUYỂN KHOẢN</button><button class="btn" style="grid-column:1/-1" onclick="otherPayment()">PHƯƠNG THỨC KHÁC</button></div>
 <div class="modal-actions"><button class="btn" onclick="closeModal()">Đóng</button></div>`);
}
function cashPayment(){const total=cartTotal();modal(`<h2>THANH TOÁN TIỀN MẶT</h2><p>Tổng tiền: <b>${money(total)}</b></p><div class="field"><label>Khách đưa (VNĐ)</label><input id="cashGiven" type="number" min="${total}" value="${total}" oninput="calcChange(${total})"></div><div class="qr-box">Tiền thừa: <b id="changeValue">0đ</b></div><div class="modal-actions"><button class="btn" onclick="showPaymentModal()">Quay lại</button><button class="btn primary" onclick="finishPayment('Tiền mặt','')">Xác nhận thanh toán</button></div>`);calcChange(total)}
function calcChange(total){const input=document.getElementById("cashGiven");const el=document.getElementById("changeValue");if(input&&el)el.textContent=money(Math.max(0,(Number(input.value)||0)-total))}
function transferPayment(){modal(`<h2>CHUYỂN KHOẢN</h2><p class="muted">Hiển thị QR do chủ quán cấu hình.</p>${state.qrData?`<div class="qr-box"><img src="${state.qrData}" alt="QR chuyển khoản"><div>${esc(state.bankName)}</div><div>${esc(state.accountHolder)} • ${esc(state.accountNumber)}</div><div class="hint">Nội dung: ${esc(state.transferNote)}</div></div>`:`<div class="qr-box">Chưa cấu hình mã QR. Chủ quán vào Quản lý / Cài đặt để thêm ảnh QR.</div>`}<p class="hint">Bản MVP chưa xác minh giao dịch ngân hàng tự động. Chỉ xác nhận sau khi nhân viên kiểm tra tiền đã vào tài khoản.</p><div class="modal-actions"><button class="btn" onclick="showPaymentModal()">Quay lại</button><button class="btn primary" onclick="finishPayment('Chuyển khoản','Nhân viên xác nhận thủ công')">Đã nhận tiền</button></div>`)}
function otherPayment(){modal(`<h2>PHƯƠNG THỨC KHÁC</h2><div class="field"><label>Phương thức</label><input id="otherMethod" placeholder="Ví dụ: Ví điện tử, công nợ"></div><div class="field"><label>Ghi chú</label><textarea id="otherNote" placeholder="Thông tin bổ sung"></textarea></div><div class="modal-actions"><button class="btn" onclick="showPaymentModal()">Quay lại</button><button class="btn primary" onclick="finishPayment(document.getElementById('otherMethod').value,document.getElementById('otherNote').value)">Xác nhận</button></div>`)}
function finishPayment(method,note){const o=getOrCreateOrder("Đã thanh toán");o.items=state.cart.map(x=>({...x}));o.total=cartTotal();o.status="Đã thanh toán";o.paymentMethod=method||"Phương thức khác";o.paymentNote=note||"";o.paidAt=new Date().toISOString();save();state.cart=[];closeModal();toast("Đã ghi nhận thanh toán demo.");render()}
function ordersTable(orders){return `<div class="table-wrap"><table><thead><tr><th>Mã đơn</th><th>Bàn</th><th>Thời gian</th><th>Tổng tiền</th><th>Trạng thái</th><th>Thanh toán</th></tr></thead><tbody>${orders.map(o=>`<tr><td>#${o.id.toString().slice(-6)}</td><td>${esc(state.tables.find(t=>t.id===o.tableId)?.name||"—")}</td><td>${new Date(o.createdAt).toLocaleString("vi-VN")}</td><td><b>${money(o.total)}</b></td><td><span class="pill ${o.status==="Chờ thanh toán"?"wait":o.status==="Đã thanh toán"?"":"busy"}">${esc(o.status)}</span></td><td>${esc(o.paymentMethod||"—")}</td></tr>`).join("")}</tbody></table></div>`}
function ordersPage(){return `${pageHead("Đơn hàng","Theo dõi các order đã tạo.")}${state.orders.length?ordersTable(state.orders.slice().reverse()):'<div class="panel empty">Chưa có đơn hàng.</div>'}`}
function menuPage(){return `${pageHead("Thực đơn","Dữ liệu demo có thể chỉnh sửa ở phiên bản tiếp theo.",'<button class="btn" onclick="addProductPrompt()">＋ Thêm món</button>')}<div class="panel"><div class="table-wrap"><table><thead><tr><th>Tên món</th><th>Nhóm</th><th>Giá bán</th><th></th></tr></thead><tbody>${state.products.map(p=>`<tr><td>${esc(p.name)}</td><td>${esc(p.category)}</td><td>${money(p.price)}</td><td><button class="btn" onclick="editProduct(${p.id})">Sửa</button> <button class="btn danger" onclick="deleteProduct(${p.id})">Xóa</button></td></tr>`).join("")}</tbody></table></div></div>`}
function addProductPrompt(){modal(`<h2>Thêm món</h2><div class="field"><label>Tên món</label><input id="prodName"></div><div class="field"><label>Nhóm món</label><input id="prodCat" placeholder="Cà phê, Trà, Đồ ăn..."></div><div class="field"><label>Giá (VNĐ)</label><input id="prodPrice" type="number" min="0"></div><div class="modal-actions"><button class="btn" onclick="closeModal()">Hủy</button><button class="btn primary" onclick="saveProduct()">Lưu món</button></div>`)}
function saveProduct(id=null){const name=document.getElementById("prodName").value.trim(),category=document.getElementById("prodCat").value.trim()||"Khác",price=Number(document.getElementById("prodPrice").value);if(!name||price<0||!Number.isFinite(price)){toast("Vui lòng nhập tên và giá hợp lệ.");return}if(id){const p=state.products.find(p=>p.id===id);Object.assign(p,{name,category,price})}else state.products.push({id:Date.now(),name,category,price});save();closeModal();render()}
function editProduct(id){const p=state.products.find(p=>p.id===id);modal(`<h2>Sửa món</h2><div class="field"><label>Tên món</label><input id="prodName" value="${esc(p.name)}"></div><div class="field"><label>Nhóm món</label><input id="prodCat" value="${esc(p.category)}"></div><div class="field"><label>Giá (VNĐ)</label><input id="prodPrice" type="number" min="0" value="${p.price}"></div><div class="modal-actions"><button class="btn" onclick="closeModal()">Hủy</button><button class="btn primary" onclick="saveProduct(${id})">Lưu thay đổi</button></div>`)}
function deleteProduct(id){if(confirm("Xóa món này khỏi thực đơn?")){state.products=state.products.filter(p=>p.id!==id);save();render()}}
function reportsPage(){const paid=state.orders.filter(o=>o.status==="Đã thanh toán");const rev=paid.reduce((s,o)=>s+o.total,0);const byMethod={};paid.forEach(o=>byMethod[o.paymentMethod||"Khác"]=(byMethod[o.paymentMethod||"Khác"]||0)+o.total);return `${pageHead("Báo cáo","Số liệu demo dựa trên các đơn đã ghi nhận.")}<div class="grid"><div class="card"><div class="stat-label">Tổng doanh thu</div><div class="stat">${money(rev)}</div></div><div class="card"><div class="stat-label">Đơn đã thanh toán</div><div class="stat">${paid.length}</div></div><div class="card"><div class="stat-label">Giá trị đơn trung bình</div><div class="stat">${money(paid.length?Math.round(rev/paid.length):0)}</div></div><div class="card"><div class="stat-label">Đơn chưa thanh toán</div><div class="stat">${state.orders.filter(o=>o.status!=="Đã thanh toán").length}</div></div></div><div class="panel" style="margin-top:16px"><h2>Doanh thu theo phương thức</h2>${Object.keys(byMethod).length?Object.entries(byMethod).map(([k,v])=>`<div class="order-line"><span>${esc(k)}</span><b>${money(v)}</b></div>`).join(""):'<div class="empty">Chưa có dữ liệu thanh toán.</div>'}</div>`}
function settingsPage(){return `${pageHead("Quản lý / Cài đặt","MVP demo: cấu hình được lưu trên trình duyệt thiết bị này.")}
 <div class="cards"><section class="panel"><h2>Thông tin cửa hàng</h2><div class="field"><label>Tên quán / chi nhánh</label><input id="settingStore" value="${esc(state.storeName)}"></div>
 <h2 style="margin-top:22px">Cấu hình Gửi in</h2><div class="field"><label>Máy in mặc định</label><select id="printerDefault"><option value="p1" ${state.printerDefault==="p1"?"selected":""}>Máy in 1</option><option value="both" ${state.printerDefault==="both"?"selected":""}>Máy in 1 + Máy in 2</option></select></div>
 <label class="checkline"><input type="checkbox" id="staffPrinter" ${state.staffCanChangePrinter?"checked":""}> Cho phép nhân viên đổi lựa chọn máy in khi gửi in</label>
 <p class="hint">Bản MVP chưa kết nối máy in thật. Quyền này hiện chỉ mô phỏng trên giao diện; chưa phải hệ thống bảo mật nhiều tài khoản.</p>
 <button class="btn primary" onclick="saveSettings()">Lưu cài đặt</button></section>
 <section class="panel"><h2>Chuyển khoản QR</h2><div class="field"><label>Tên ngân hàng</label><input id="bankName" value="${esc(state.bankName)}" placeholder="Ví dụ: Vietcombank"></div><div class="field"><label>Số tài khoản</label><input id="accountNumber" value="${esc(state.accountNumber)}" placeholder="Số tài khoản nhận tiền"></div><div class="field"><label>Chủ tài khoản</label><input id="accountHolder" value="${esc(state.accountHolder)}" placeholder="Tên chủ tài khoản"></div><div class="field"><label>Nội dung chuyển khoản gợi ý</label><input id="transferNote" value="${esc(state.transferNote)}"></div>
 <div class="field"><label>Ảnh QR (chọn ảnh từ điện thoại)</label><input id="qrFile" type="file" accept="image/*"><div class="hint">Ảnh QR được lưu cục bộ trên trình duyệt. Chưa đồng bộ lên Cloud.</div></div>
 <div class="qr-box">${state.qrData?`<img src="${state.qrData}" alt="QR hiện tại">`:"Chưa thêm mã QR"}</div><div class="actions"><button class="btn primary" onclick="saveSettings()">Lưu thông tin</button><button class="btn" onclick="removeQR()">Xóa QR</button></div></section></div>
 <div class="panel" style="margin-top:16px"><h2>Dữ liệu demo</h2><p class="hint">Mọi dữ liệu hiện lưu trong bộ nhớ trình duyệt của thiết bị. Xóa dữ liệu trình duyệt có thể làm mất dữ liệu. Chưa có đăng nhập thật, đồng bộ Cloud, phân quyền bảo mật, in vật lý hoặc xác minh ngân hàng.</p><div class="actions"><button class="btn" onclick="exportData()">Xuất bản sao dữ liệu</button><button class="btn danger" onclick="resetDemo()">Đặt lại dữ liệu demo</button></div></div>`}
async function saveSettings(){state.storeName=document.getElementById("settingStore")?.value.trim()||state.storeName;state.printerDefault=document.getElementById("printerDefault")?.value||state.printerDefault;state.staffCanChangePrinter=!!document.getElementById("staffPrinter")?.checked;state.bankName=document.getElementById("bankName")?.value.trim()||"";state.accountNumber=document.getElementById("accountNumber")?.value.trim()||"";state.accountHolder=document.getElementById("accountHolder")?.value.trim()||"";state.transferNote=document.getElementById("transferNote")?.value.trim()||"";const file=document.getElementById("qrFile")?.files?.[0];if(file){if(file.size>1200000){toast("Ảnh QR quá lớn. Hãy chọn ảnh dưới 1,2 MB.");return}state.qrData=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)}).catch(()=>state.qrData)}save();render();toast("Đã lưu cài đặt trên thiết bị này.")}
function removeQR(){state.qrData="";save();render();toast("Đã xóa ảnh QR demo.")}
function addTable(){const n=state.tables.length+1;state.tables.push({id:Date.now(),name:"Bàn "+String(n).padStart(2,"0")});save();render()}
function exportData(){const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="man-pos-demo-backup.json";a.click();URL.revokeObjectURL(a.href)}
function resetDemo(){if(confirm("Bạn có chắc muốn xóa đơn hàng và đặt lại dữ liệu demo?")){localStorage.removeItem(KEY);state=structuredClone(defaultState);save();state.currentTable=null;state.cart=[];render();toast("Đã đặt lại dữ liệu demo.")}}
function modal(content){document.getElementById("modalRoot").innerHTML=`<div class="modal-backdrop" onclick="if(event.target===this)closeModal()"><div class="modal">${content}</div></div>`}
function closeModal(){document.getElementById("modalRoot").innerHTML=""}
render();
