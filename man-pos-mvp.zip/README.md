# Mạn POS MVP — bản thử nghiệm

Đây là nguyên mẫu web chạy trên điện thoại/trình duyệt, có thể đưa lên GitHub Pages miễn phí.

## Có gì trong bản này
- Trang tổng quan
- Bán hàng theo bàn
- Thực đơn demo và thêm/sửa/xóa món
- Gửi in: Máy in 1 hoặc Máy in 1 + Máy in 2
- Chủ quán đặt máy in mặc định và bật/tắt quyền nhân viên đổi lựa chọn
- Thanh toán demo: tiền mặt (tính tiền thừa), chuyển khoản (hiển thị QR chủ quán tải lên), phương thức khác kèm ghi chú
- Danh sách đơn hàng và báo cáo cơ bản
- Dữ liệu lưu trong `localStorage` của trình duyệt

## Giới hạn quan trọng
Đây CHƯA phải phần mềm thương mại hoàn chỉnh:
- Chưa có tài khoản đăng nhập thật hoặc phân quyền an toàn
- Chưa có database/server/đồng bộ nhiều thiết bị
- Chưa in ra máy in vật lý
- Chưa tích hợp hoặc xác minh ngân hàng
- QR và cài đặt chỉ lưu cục bộ trên trình duyệt đang dùng
- Không dùng dữ liệu demo cho vận hành quán thật

## Chạy thử
Mở `index.html` trong trình duyệt hoặc bật GitHub Pages cho repository.

## Đưa lên GitHub Pages
1. Tạo repository mới tên `man-pos`.
2. Upload toàn bộ file trong thư mục này lên thư mục gốc của repository.
3. Vào Settings → Pages.
4. Ở Build and deployment, chọn Deploy from a branch.
5. Chọn branch `main`, folder `/(root)`, nhấn Save.
6. Đợi GitHub tạo địa chỉ Pages trong phần Settings → Pages.

Đây là web app prototype. Có thể “Add to Home screen” trên Chrome Android để mở giống ứng dụng, nhưng chưa phải APK native.
